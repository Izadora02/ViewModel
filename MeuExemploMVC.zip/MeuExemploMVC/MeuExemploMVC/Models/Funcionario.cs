﻿namespace MeuExemploMVC.Models
{
    public class Funcionario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cidade { get; set; }
        public string Genero { get; set; }


    }
}
