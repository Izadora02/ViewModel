﻿namespace MeuExemploMVC.Models
{
    public class Departamento
    {
        public int DepId { get; set; }
        public string DepNome { get; set; }
    }
}
