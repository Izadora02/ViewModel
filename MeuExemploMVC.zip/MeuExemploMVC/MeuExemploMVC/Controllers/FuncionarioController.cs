﻿using MeuExemploMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace MeuExemploMVC.Controllers
{
    public class FuncionarioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        public IActionResult DetalhesFunc()
        {
            Funcionario func = new Funcionario()
            {
                Id = 1,
                Nome = "Izadora",
                Cidade = "São Paulo",
                Genero = "Feminino"
            };

            Departamento dep = new Departamento()
            {
                DepId = 1,
                DepNome = "HR"
            };

            DetalhesFuncViewModel funcView = new DetalhesFuncViewModel() { 
                dep = dep ,
                func = func,
                titulo = "Funcionario ViewModel",
                header = "Detalhes Funcionario"
            };

            return View(funcView);
        }
    }
}
