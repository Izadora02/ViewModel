﻿using MeuExemploMVC.Models;

namespace MeuExemploMVC.Models
{
    public class DetalhesFuncViewModel
    {
        public Funcionario func { get; set; }
        public Departamento dep { get; set; }

        public string titulo { get; set; }
        public string header { get; set; }
    }
}
